import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-casomal',
  templateUrl: './casomal.page.html',
  styleUrls: ['./casomal.page.scss'],
})
export class CasomalPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
